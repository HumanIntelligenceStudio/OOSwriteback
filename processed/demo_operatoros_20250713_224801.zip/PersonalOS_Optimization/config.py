"""
Configuration for PersonalOS_Optimization
Personalized settings based on your soulprint analysis
"""

import os
from datetime import datetime

# Project Settings
PROJECT_NAME = "PersonalOS_Optimization"
PROJECT_TYPE = "hybrid"
FOCUS_AREA = "optimization"

# User Preferences (from soulprint analysis)
TECHNICAL_COMFORT = 3
AUTOMATION_LEVEL = 3
ENERGY_PATTERN = "balanced"

# System Settings
DEBUG_MODE = True
LOG_LEVEL = "INFO"
DATA_DIR = "data"
BACKUP_DIR = "backups"

# API Settings (customize as needed)
API_TIMEOUT = 30
MAX_RETRIES = 3
RATE_LIMIT = 100

# Optimization Settings
OPTIMIZATION_INTERVAL = 3600  # 1 hour
AUTO_BACKUP = True
NOTIFICATION_ENABLED = True

def get_user_config():
    """Get user-specific configuration"""
    return {
        'project_name': PROJECT_NAME,
        'focus_area': FOCUS_AREA,
        'technical_comfort': TECHNICAL_COMFORT,
        'automation_level': AUTOMATION_LEVEL,
        'energy_pattern': ENERGY_PATTERN
    }

def setup_directories():
    """Create necessary directories"""
    directories = [DATA_DIR, BACKUP_DIR, 'logs', 'templates']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    print(f"{PROJECT_NAME} directories created successfully!")

if __name__ == "__main__":
    setup_directories()
    print(f"Configuration loaded for {PROJECT_NAME}")
    print(f"Focus area: {FOCUS_AREA}")
    print(f"Technical comfort: {TECHNICAL_COMFORT}/5")
    print(f"Automation level: {AUTOMATION_LEVEL}/5")
