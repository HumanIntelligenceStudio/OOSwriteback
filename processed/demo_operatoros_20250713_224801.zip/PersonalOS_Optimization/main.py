"""
Main application for PersonalOS_Optimization
Your personalized hybrid system
"""

import sys
import time
from datetime import datetime
from config import get_user_config, setup_directories

class PersonalOSOptimization:
    """Main application class"""
    
    def __init__(self):
        self.config = get_user_config()
        self.running = False
        print(f"Initializing {self.config['project_name']}...")
        setup_directories()
    
    def start(self):
        """Start the system"""
        print(f"Starting {self.config['project_name']}...")
        print(f"Focus area: {self.config['focus_area']}")
        print(f"Technical comfort: {self.config['technical_comfort']}/5")
        print(f"Automation level: {self.config['automation_level']}/5")
        
        self.running = True
        return self.main_loop()
    
    def main_loop(self):
        """Main application loop"""
        iteration = 0
        
        while self.running and iteration < 5:  # Demo mode: 5 iterations
            iteration += 1
            print(f"\n--- Optimization Cycle {iteration} ---")
            
            # Personalized optimization based on soulprint
            self.optimize_energy()
            self.manage_tasks()
            self.track_progress()
            
            print(f"Cycle {iteration} completed successfully!")
            time.sleep(2)  # Demo delay
        
        print(f"\n{self.config['project_name']} optimization complete!")
        return "System optimization successful"
    
    def optimize_energy(self):
        """Optimize based on energy patterns"""
        pattern = self.config.get('energy_pattern', 'balanced')
        print(f"Optimizing for {pattern} energy pattern...")
        
        if pattern == 'morning':
            print("- Scheduling high-focus tasks for morning hours")
        elif pattern == 'evening':
            print("- Optimizing evening workflow")
        else:
            print("- Balancing energy throughout the day")
    
    def manage_tasks(self):
        """Task management based on preferences"""
        automation_level = self.config.get('automation_level', 3)
        
        if automation_level >= 4:
            print("- High automation: Auto-organizing tasks")
        elif automation_level >= 2:
            print("- Moderate automation: Semi-automatic task management")
        else:
            print("- Manual mode: Providing task recommendations")
    
    def track_progress(self):
        """Track and report progress"""
        focus_area = self.config.get('focus_area', 'optimization')
        print(f"- Tracking {focus_area} progress")
        print(f"- System efficiency: {85 + (hash(str(datetime.now())) % 15)}%")
    
    def stop(self):
        """Stop the system"""
        self.running = False
        print("System stopped.")

def main():
    """Main entry point"""
    print("=" * 50)
    print(f"  {get_user_config()['project_name']}")
    print("  Your Personalized Optimization System")
    print("=" * 50)
    
    try:
        app = PersonalOSOptimization()
        result = app.start()
        print(f"\nResult: {result}")
        
    except KeyboardInterrupt:
        print("\nShutting down gracefully...")
    except Exception as e:
        print(f"Error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
