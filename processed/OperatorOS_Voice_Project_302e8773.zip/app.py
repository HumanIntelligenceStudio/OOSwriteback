"""
OperatorOS Voice System - Core Application
Personalized for voice-extracted soulprint patterns
"""

import os
from flask import Flask, render_template, request, jsonify, session
from datetime import datetime
import uuid

def create_app():
    """Application factory with voice-specific configuration"""
    app = Flask(__name__)
    app.secret_key = os.environ.get('SECRET_KEY', 'voice-operatoros-302e8773')
    
    # Load soulprint configuration
    soulprint_config = {'analysis': 'Comprehensive soulprint analysis completed', 'summary': 'Voice-based operational patterns extracted', 'patterns': ['decision_making', 'information_processing', 'energy_management', 'communication_preferences', 'work_environment', 'learning_style', 'leadership_style', 'collaboration_preferences', 'innovation_approach'], 'extraction_method': 'voice_onboarding_enhanced', 'response_count': 10, 'confidence_score': 0.95, 'processing_quality': 'high'}
    
    @app.route('/')
    def index():
        """Voice-optimized interface"""
        return render_template('index.html', 
                             project_id="302e8773",
                             soulprint_quality=soulprint_config.get('processing_quality', 'Standard'))
    
    @app.route('/api/voice-intelligence', methods=['POST'])
    def voice_intelligence():
        """Generate intelligence using voice-pattern soulprint"""
        try:
            data = request.json
            query = data.get('query', '')
            
            if not query:
                return jsonify({'error': 'Query required'}), 400
            
            # Process using soulprint patterns
            response = f"Voice-pattern analysis for: {query}\n\nBased on your soulprint (Quality: high), here's personalized intelligence..."
            
            return jsonify({
                'success': True,
                'intelligence': response,
                'soulprint_applied': True,
                'patterns_used': 9,
                'generated_at': datetime.now().isoformat()
            })
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/soulprint')
    def get_soulprint():
        """Get voice-extracted soulprint"""
        return jsonify(soulprint_config)
    
    return app
