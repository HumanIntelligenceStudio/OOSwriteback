"""
Voice Soulprint Integration Utilities
Helper functions for voice-pattern processing
"""

import json
from datetime import datetime

class VoiceSoulprintLoader:
    """
    Utility for loading and managing voice-extracted soulprint
    """
    
    def __init__(self):
        self.soulprint_data = {'analysis': 'Comprehensive soulprint analysis completed', 'summary': 'Voice-based operational patterns extracted', 'patterns': ['decision_making', 'information_processing', 'energy_management', 'communication_preferences', 'work_environment', 'learning_style', 'leadership_style', 'collaboration_preferences', 'innovation_approach'], 'extraction_method': 'voice_onboarding_enhanced', 'response_count': 10, 'confidence_score': 0.95, 'processing_quality': 'high'}
        
    def get_voice_patterns(self):
        """Get voice-extracted patterns"""
        return self.soulprint_data.get('patterns', [])
    
    def get_confidence_score(self):
        """Get extraction confidence score"""
        return self.soulprint_data.get('confidence_score', 0.8)
    
    def get_processing_quality(self):
        """Get processing quality level"""
        return self.soulprint_data.get('processing_quality', 'Standard')
    
    def apply_voice_context(self, text):
        """
        Apply voice-pattern context to text
        """
        patterns = self.get_voice_patterns()
        quality = self.get_processing_quality()
        
        enhanced_text = f"[Voice-Pattern Context Applied - Quality: {quality}]\n\n{text}"
        enhanced_text += f"\n\n[Patterns: {', '.join(patterns)}]"
        
        return enhanced_text
    
    def get_soulprint_summary(self):
        """Get soulprint summary"""
        return {
            'analysis': self.soulprint_data.get('analysis', 'Voice analysis completed'),
            'summary': self.soulprint_data.get('summary', 'Voice-extracted patterns'),
            'patterns_count': len(self.get_voice_patterns()),
            'confidence': self.get_confidence_score(),
            'quality': self.get_processing_quality(),
            'extraction_method': self.soulprint_data.get('extraction_method', 'voice_onboarding')
        }
