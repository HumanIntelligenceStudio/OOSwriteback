"""
OperatorOS Voice-Generated System
Project ID: adc92f06
Generated: 2025-07-13 23:33:35
"""

from app import create_app

# Create application instance
app = create_app()

if __name__ == '__main__':
    print("🎤 OperatorOS Voice-Generated System Starting...")
    print(f"📊 Soulprint Quality: high")
    print(f"🎯 Patterns: 9")
    print("🚀 Ready for voice-pattern intelligence!")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
