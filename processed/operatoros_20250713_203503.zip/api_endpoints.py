"""
API Endpoints for OperatorOS UI Integration
Provides data layer for existing HTML interface
"""

import json
from flask import Flask, jsonify, request
from datetime import datetime

app = Flask(__name__)

class OperatorOSAPI:
    """Simple API layer for UI integration"""
    
    def __init__(self):
        self.load_user_data()
    
    def load_user_data(self):
        """Load user profile and configuration"""
        try:
            with open("user_profile.json", "r") as f:
                self.user_profile = json.load(f)
        except FileNotFoundError:
            self.user_profile = {}
        
        try:
            with open("data_config.json", "r") as f:
                self.config = json.load(f)
        except FileNotFoundError:
            self.config = {}

@app.route("/api/user-profile")
def get_user_profile():
    """Get user soulprint and profile data"""
    api = OperatorOSAPI()
    return jsonify(api.user_profile)

@app.route("/api/daily-routine")
def get_daily_routine():
    """Get personalized daily routine"""
    api = OperatorOSAPI()
    
    optimization_priority = api.user_profile.get("soulprint_summary", {}).get("optimization_priority", "systematic_optimization")
    
    routine = {
        "timestamp": datetime.now().isoformat(),
        "focus_area": optimization_priority,
        "actions": generate_daily_actions(optimization_priority),
        "reflection_prompts": [
            "What pattern did I notice about my thinking today?",
            "Where did I experience the most friction, and why?",
            "How did I leverage my natural strengths?",
            "What one optimization would have the biggest impact tomorrow?"
        ]
    }
    
    return jsonify(routine)

@app.route("/api/optimization-insights")
def get_optimization_insights():
    """Get personalized optimization insights"""
    api = OperatorOSAPI()
    
    insights = {
        "primary_strength": api.user_profile.get("soulprint_summary", {}).get("primary_strength", ""),
        "main_friction": api.user_profile.get("soulprint_summary", {}).get("main_friction", ""),
        "optimization_recommendations": generate_optimization_recommendations(api.user_profile),
        "next_steps": generate_next_steps(api.user_profile)
    }
    
    return jsonify(insights)

@app.route("/api/track-progress", methods=["POST"])
def track_progress():
    """Track optimization progress"""
    data = request.json
    
    tracking_data = {
        "timestamp": datetime.now().isoformat(),
        "data": data,
        "alignment_score": calculate_alignment_score(data)
    }
    
    # Save tracking data (implementation depends on storage choice)
    save_tracking_data(tracking_data)
    
    return jsonify({"status": "success", "tracking_data": tracking_data})

def generate_daily_actions(optimization_priority):
    """Generate personalized daily actions"""
    
    action_map = {
        "decision_clarity": [
            "Review pending decisions and apply decision framework",
            "Identify one decision that's creating friction",
            "Use your systematic thinking to break complex decisions into components"
        ],
        "time_optimization": [
            "Track time spent on high-value activities",
            "Identify and eliminate one time-wasting pattern", 
            "Optimize your most productive hours for important work"
        ],
        "energy_management": [
            "Monitor energy levels throughout the day",
            "Align challenging tasks with peak energy periods",
            "Implement one energy restoration practice"
        ]
    }
    
    return action_map.get(optimization_priority, [
        "Review and optimize one system or process",
        "Identify one area for systematic improvement",
        "Implement one small optimization that compounds over time"
    ])

def generate_optimization_recommendations(user_profile):
    """Generate personalized optimization recommendations"""
    
    return [
        "Focus on your natural strength in systematic thinking",
        "Create decision frameworks to reduce friction",
        "Implement daily tracking for continuous improvement",
        "Build automated systems for routine tasks"
    ]

def generate_next_steps(user_profile):
    """Generate personalized next steps"""
    
    return [
        "Complete daily optimization routine",
        "Track one key metric related to your optimization priority",
        "Review and update your personal systems weekly",
        "Connect with OperatorOS platform for enhanced intelligence"
    ]

def calculate_alignment_score(data):
    """Calculate soulprint alignment score"""
    # Simple scoring logic - can be enhanced based on specific patterns
    return 0.85

def save_tracking_data(data):
    """Save tracking data to storage"""
    # Implementation depends on chosen storage method
    pass

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
